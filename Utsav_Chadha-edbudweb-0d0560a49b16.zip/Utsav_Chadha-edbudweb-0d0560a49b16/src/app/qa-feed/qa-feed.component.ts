import { Component, OnInit } from '@angular/core';
import { QuestionsService } from '../shared/questions.service';
import { Question } from '../models/question';
import { Router } from '@angular/router';

import { CustomUtils } from '../utils/customUtils';

@Component({
  selector: 'app-qa-feed',
  templateUrl: './qa-feed.component.html',
  styleUrls: ['./qa-feed.component.css']
})
export class QaFeedComponent implements OnInit {
  questions: Question[] = [];
  questionIdQuestionMap = {};
  utils: CustomUtils;
  qData: Question;
  constructor(private qaService: QuestionsService,
              private router: Router,
              ) {
                this.utils = new CustomUtils();
        }

  navigateToAnswers(qId, qText) {
    qText = this.utils.stringToUrl(qText);
    this.router.navigate(['/questions', qId, qText]);
  }
  ngOnInit() {
    this.qaService.getQuestions().subscribe(questionsSnapshot => {
      questionsSnapshot.forEach(question => {
        // console.log(question);
        const qData: Question = <Question>question.payload.doc.data();
        qData.id = question.payload.doc.id;
        this.questions.push(qData);

        // this.questions.id = question.payload.doc.id;
      });
    });

    }
  }


