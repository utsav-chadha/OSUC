import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-qa-menu',
  templateUrl: './qa-menu.component.html',
  styleUrls: ['./qa-menu.component.css']
})
export class QaMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
