import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-expert-feed',
  templateUrl: './expert-feed.component.html',
  styleUrls: ['./expert-feed.component.css']
})
export class ExpertFeedComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
